<?php
require_once("include/init.php");
require_once("include/header.php");
?>

<?php
require_once("include/footer.php");
?>
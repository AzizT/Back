<nav class="text-center bg-info">

    <a href="accueil.php" class="alert-link text-dark p-1">Accueil</a>
    <a href="actualites.php" class="alert-link text-dark p-1">Actualités</a>
    <a href="contact.php" class="alert-link text-dark p-1">Contact</a>
    <a href="qui_sommes_nous.php" class="alert-link text-dark p-1">Qui sommes nous</a>

</nav> 
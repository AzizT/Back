<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Accueil</title>

    <!-- link bootstrap -->

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container">

        <header class="d-flex p-4 bg-secondary">
            <img src="https://yt3.ggpht.com/a-/AAuE7mA4dRDwDy8JWy7tk6zTQH_UQPB0ygndiBRzpw=s900-mo-c-c0xffffffff-rj-k-no" alt="Nassim...ou pas ???" style="height: 150px; width: 150px" class="m-2">
            <h1 class="text-warning">Nassim Academy...muscle ton jeu !</h1>

        </header> 
<?php
require_once("include/header.php");
// va permettre d' aller chercher le header dans le dossier include ( et aisni ne modifier qu' un seul fichier pour en modifier plusieurs autres)
require_once("include/nav.php");

?>

<section class="p-4 text-center border border-dark" style="height:400px">

    voici le contenu de la page QSN <br>
    voici le contenu de la page QSN <br>
    voici le contenu de la page QSN <br>
    voici le contenu de la page QSN <br>
    voici le contenu de la page QSN <br>



</section>

<?php
require_once("include/footer.php");

?> 